#!/usr/bin/env python3
"""
Key Authentication System - Telegram Admin Bot
Uses python-telegram-bot v20+ (async)

Commands:
  /start      - Show admin menu
  /gen <dur>  - Generate key (1d, 7d, 30d, etc.)
  /check <key> - Check key info
  /list       - List all keys
  /listactive - List active keys only
  /del <key>  - Delete key
  /ban <key>  - Ban key
  /reset <key> - Reset HWID binding
  /help       - Show help
"""

import os
import sys
import logging
import asyncio
import httpx
from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    CallbackQueryHandler,
)
from telegram.constants import ParseMode

# ─── Config ───────────────────────────────────────────────────────────────────

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
ADMIN_IDS_RAW = os.environ.get("TELEGRAM_ADMIN_IDS", "")
ADMIN_IDS = set(int(x.strip()) for x in ADMIN_IDS_RAW.split(",") if x.strip().isdigit())
API_BASE = os.environ.get("API_BASE_URL", "").rstrip("/")
ADMIN_API_KEY = os.environ.get("ADMIN_API_KEY", "")

# ─── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

# ─── Startup checks ───────────────────────────────────────────────────────────

def check_config():
    missing = []
    if not BOT_TOKEN:
        missing.append("TELEGRAM_BOT_TOKEN")
    if not ADMIN_IDS:
        missing.append("TELEGRAM_ADMIN_IDS")
    if not API_BASE:
        missing.append("API_BASE_URL")
    if not ADMIN_API_KEY:
        missing.append("ADMIN_API_KEY")
    if missing:
        logger.error(f"Missing environment variables: {', '.join(missing)}")
        sys.exit(1)
    logger.info(f"Config OK | API: {API_BASE} | Admins: {ADMIN_IDS}")

# ─── API Client ───────────────────────────────────────────────────────────────

async def api_request(method: str, endpoint: str, **kwargs) -> dict:
    """Make authenticated request to Key Auth API."""
    url = f"{API_BASE}{endpoint}"
    headers = {
        "Content-Type": "application/json",
        "x-api-key": ADMIN_API_KEY,
    }
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.request(method, url, headers=headers, **kwargs)
            data = resp.json()
            data["_http_status"] = resp.status_code
            return data
    except httpx.TimeoutException:
        return {"error": "Request timed out", "_http_status": 408}
    except httpx.ConnectError:
        return {"error": f"Cannot connect to API server: {API_BASE}", "_http_status": 503}
    except Exception as e:
        return {"error": str(e), "_http_status": 500}

# ─── Auth decorator ───────────────────────────────────────────────────────────

def admin_only(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if ADMIN_IDS and user_id not in ADMIN_IDS:
            await update.message.reply_text(
                "⛔ *Access Denied*\nYou are not authorized to use this bot.",
                parse_mode=ParseMode.MARKDOWN,
            )
            logger.warning(f"Unauthorized access attempt by user {user_id}")
            return
        return await func(update, context)
    wrapper.__name__ = func.__name__
    return wrapper

# ─── Helpers ──────────────────────────────────────────────────────────────────

def fmt_ts(ts):
    if not ts or ts > 9000000000000:
        return "Never"
    try:
        return datetime.utcfromtimestamp(ts / 1000).strftime("%Y-%m-%d %H:%M UTC")
    except Exception:
        return str(ts)

def status_emoji(status):
    return {"active": "✅", "expired": "⏰", "banned": "🚫"}.get(status, "❓")

def escape_md(text):
    """Escape special MarkdownV2 chars."""
    special = r'_*[]()~`>#+-=|{}.!'
    return ''.join(f'\\{c}' if c in special else c for c in str(text))

# ─── Command Handlers ─────────────────────────────────────────────────────────

@admin_only
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📋 List Keys", callback_data="list"),
         InlineKeyboardButton("➕ Gen 7d", callback_data="gen_7d")],
        [InlineKeyboardButton("➕ Gen 1d", callback_data="gen_1d"),
         InlineKeyboardButton("➕ Gen 30d", callback_data="gen_30d")],
        [InlineKeyboardButton("❓ Help", callback_data="help")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    text = (
        "🔐 *Key Authentication System*\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        "Welcome, Admin!\n\n"
        "Use the buttons below or send commands:\n"
        "`/gen 7d` — Generate key\n"
        "`/check KEY` — Check key info\n"
        "`/list` — List all keys\n"
        "`/del KEY` — Delete key\n"
        "`/ban KEY` — Ban key\n"
        "`/reset KEY` — Reset HWID\n"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=reply_markup)


@admin_only
async def cmd_gen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    duration = args[0] if args else "7d"

    msg = await update.message.reply_text(f"⏳ Generating `{duration}` key...")

    data = await api_request("POST", "/api/createKey", json={"duration": duration})

    if data.get("error"):
        await msg.edit_text(f"❌ Error: {data['error']}")
        return

    text = (
        f"✅ *Key Generated*\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"🔑 Key: `{data['key']}`\n"
        f"⏳ Duration: `{duration}`\n"
        f"📅 Expires: `{data.get('expired_at_human', 'N/A')}`\n"
        f"🖥️ Max Devices: `{data.get('max_devices', 1)}`\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"_Copy the key above and share with user_"
    )
    await msg.edit_text(text, parse_mode=ParseMode.MARKDOWN)


@admin_only
async def cmd_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: `/check XXXX-XXXX-XXXX-XXXX`", parse_mode=ParseMode.MARKDOWN)
        return

    key = context.args[0].upper()
    msg = await update.message.reply_text(f"🔍 Checking key `{key}`...")

    data = await api_request("GET", f"/api/keyInfo?key={key}")

    if data.get("error"):
        await msg.edit_text(f"❌ {data['error']}")
        return

    st = data.get("status", "unknown")
    emoji = status_emoji(st)
    days = data.get("days_remaining")
    days_str = f"{days}d" if days is not None else "N/A"

    text = (
        f"🔑 *Key Details*\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"Key: `{data['key']}`\n"
        f"Status: {emoji} `{st.upper()}`\n"
        f"Created: `{data.get('created_at_human', 'N/A')}`\n"
        f"Expires: `{data.get('expired_at_human', 'N/A')}`\n"
        f"Days Left: `{days_str}`\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"🖥️ Devices: `{data.get('devices_used', 0)}/{data.get('max_devices', 1)}`\n"
        f"HWID: `{data.get('hwid') or 'Not bound'}`\n"
        f"Usage Count: `{data.get('usage_count', 0)}`\n"
        f"Note: `{data.get('note') or 'None'}`\n"
    )
    await msg.edit_text(text, parse_mode=ParseMode.MARKDOWN)


@admin_only
async def cmd_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    status_filter = "all"
    if context.args:
        sf = context.args[0].lower()
        if sf in ("active", "expired", "banned"):
            status_filter = sf

    msg = await update.message.reply_text("⏳ Fetching key list...")

    data = await api_request("GET", f"/api/listKeys?status={status_filter}&limit=30")

    if data.get("error"):
        await msg.edit_text(f"❌ {data['error']}")
        return

    keys = data.get("keys", [])
    stats = data.get("stats", {})
    pagination = data.get("pagination", {})

    header = (
        f"📋 *Key List* [{status_filter.upper()}]\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"Total: `{stats.get('total',0)}` | "
        f"✅ `{stats.get('active',0)}` | "
        f"⏰ `{stats.get('expired',0)}` | "
        f"🚫 `{stats.get('banned',0)}`\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
    )

    if not keys:
        await msg.edit_text(header + "_No keys found._", parse_mode=ParseMode.MARKDOWN)
        return

    lines = []
    for k in keys[:25]:  # Max 25 in one message
        emoji = status_emoji(k.get("status", ""))
        bound = "🔒" if k.get("hwid_bound") else "🔓"
        lines.append(
            f"{emoji} `{k['key']}` {bound}\n"
            f"  📅 {k.get('expired_at_human','N/A')} | 👤 {k.get('devices_used',0)}/{k.get('max_devices',1)}"
        )

    body = "\n".join(lines)
    total_shown = pagination.get("total", len(keys))
    footer = f"\n\n_Showing {min(25, len(keys))} of {total_shown} keys_"

    await msg.edit_text(header + body + footer, parse_mode=ParseMode.MARKDOWN)


@admin_only
async def cmd_del(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: `/del XXXX-XXXX-XXXX-XXXX`", parse_mode=ParseMode.MARKDOWN)
        return

    key = context.args[0].upper()

    # Confirmation inline keyboard
    keyboard = [
        [
            InlineKeyboardButton("✅ Confirm Delete", callback_data=f"confirm_del_{key}"),
            InlineKeyboardButton("❌ Cancel", callback_data="cancel"),
        ]
    ]
    await update.message.reply_text(
        f"⚠️ Are you sure you want to *permanently delete* key:\n`{key}`?",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


@admin_only
async def cmd_ban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: `/ban XXXX-XXXX-XXXX-XXXX`", parse_mode=ParseMode.MARKDOWN)
        return

    key = context.args[0].upper()
    reason = " ".join(context.args[1:]) or "Banned by admin"

    msg = await update.message.reply_text(f"⏳ Banning key `{key}`...")

    data = await api_request("POST", "/api/banKey", json={"key": key, "reason": reason})

    if data.get("error"):
        await msg.edit_text(f"❌ {data['error']}")
        return

    await msg.edit_text(
        f"🚫 *Key Banned*\n"
        f"Key: `{key}`\n"
        f"Reason: `{reason}`",
        parse_mode=ParseMode.MARKDOWN,
    )


@admin_only
async def cmd_reset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: `/reset XXXX-XXXX-XXXX-XXXX`", parse_mode=ParseMode.MARKDOWN)
        return

    key = context.args[0].upper()
    msg = await update.message.reply_text(f"⏳ Resetting HWID for `{key}`...")

    data = await api_request("POST", "/api/resetHWID", json={"key": key})

    if data.get("error"):
        await msg.edit_text(f"❌ {data['error']}")
        return

    await msg.edit_text(
        f"🔄 *HWID Reset*\n"
        f"Key: `{key}`\n"
        f"_Key can now register on a new device._",
        parse_mode=ParseMode.MARKDOWN,
    )


@admin_only
async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "📖 *Bot Commands*\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        "`/gen <dur>` — Generate key\n"
        "  Duration: `1h` `1d` `7d` `30d` `1m`\n\n"
        "`/check <key>` — View key details\n\n"
        "`/list [status]` — List keys\n"
        "  Filter: `active` `expired` `banned`\n\n"
        "`/del <key>` — Delete key permanently\n\n"
        "`/ban <key> [reason]` — Ban key\n\n"
        "`/reset <key>` — Reset HWID binding\n\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        "🔑 Key Format: `XXXX-XXXX-XXXX-XXXX`"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

# ─── Inline Button Callbacks ──────────────────────────────────────────────────

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    if ADMIN_IDS and user_id not in ADMIN_IDS:
        await query.answer("⛔ Unauthorized", show_alert=True)
        return

    await query.answer()
    data = query.data

    if data == "cancel":
        await query.edit_message_text("❌ Cancelled.")

    elif data == "list":
        context.args = []
        await query.message.reply_text("⏳ Fetching keys...")
        # Trigger list command via fake update
        ctx_data = await api_request("GET", "/api/listKeys?status=all&limit=30")
        keys = ctx_data.get("keys", [])
        stats = ctx_data.get("stats", {})
        
        header = (
            f"📋 *Key List*\n"
            f"Total: `{stats.get('total',0)}` | ✅ `{stats.get('active',0)}` | "
            f"⏰ `{stats.get('expired',0)}` | 🚫 `{stats.get('banned',0)}`\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
        )
        if not keys:
            await query.message.reply_text(header + "_No keys._", parse_mode=ParseMode.MARKDOWN)
        else:
            lines = []
            for k in keys[:20]:
                emoji = status_emoji(k.get("status", ""))
                lines.append(f"{emoji} `{k['key']}` | {k.get('expired_at_human','N/A')}")
            await query.message.reply_text(header + "\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    elif data.startswith("gen_"):
        duration = data.split("_", 1)[1]
        result = await api_request("POST", "/api/createKey", json={"duration": duration})
        if result.get("error"):
            await query.message.reply_text(f"❌ {result['error']}")
        else:
            await query.message.reply_text(
                f"✅ *Key Generated*\n"
                f"🔑 `{result['key']}`\n"
                f"📅 Expires: `{result.get('expired_at_human','N/A')}`",
                parse_mode=ParseMode.MARKDOWN,
            )

    elif data.startswith("confirm_del_"):
        key = data.split("confirm_del_", 1)[1]
        result = await api_request("POST", "/api/deleteKey", json={"key": key})
        if result.get("error"):
            await query.edit_message_text(f"❌ {result['error']}")
        else:
            await query.edit_message_text(f"🗑️ Key `{key}` deleted.", parse_mode=ParseMode.MARKDOWN)

    elif data == "help":
        text = (
            "📖 *Commands*\n"
            "`/gen 7d` — Generate 7-day key\n"
            "`/check KEY` — Check key info\n"
            "`/list` — List all keys\n"
            "`/del KEY` — Delete key\n"
            "`/ban KEY` — Ban key\n"
            "`/reset KEY` — Reset HWID\n"
        )
        await query.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    check_config()

    app = Application.builder().token(BOT_TOKEN).build()

    # Register handlers
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("gen", cmd_gen))
    app.add_handler(CommandHandler("check", cmd_check))
    app.add_handler(CommandHandler("list", cmd_list))
    app.add_handler(CommandHandler("listactive", lambda u, c: cmd_list(u, c)))
    app.add_handler(CommandHandler("del", cmd_del))
    app.add_handler(CommandHandler("ban", cmd_ban))
    app.add_handler(CommandHandler("reset", cmd_reset))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CallbackQueryHandler(button_callback))

    logger.info("🤖 Bot starting...")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
