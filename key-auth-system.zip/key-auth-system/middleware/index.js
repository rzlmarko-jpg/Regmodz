/**
 * Middleware: Rate Limiter + Admin Auth + CORS + Logger
 * Simple in-memory rate limiter for Vercel Serverless
 */

// In-memory rate limit store (resets per cold start)
const rateLimitStore = new Map();

/**
 * Rate limiter - max N requests per IP per window
 */
function rateLimit(req, maxRequests = 30, windowMs = 60 * 1000) {
  const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 
             req.headers['x-real-ip'] || 
             req.socket?.remoteAddress || 
             'unknown';
  
  const now = Date.now();
  const key = `${ip}:${req.url?.split('?')[0]}`;
  
  const entry = rateLimitStore.get(key) || { count: 0, resetAt: now + windowMs };
  
  // Reset window if expired
  if (now > entry.resetAt) {
    entry.count = 0;
    entry.resetAt = now + windowMs;
  }
  
  entry.count++;
  rateLimitStore.set(key, entry);
  
  // Cleanup old entries periodically
  if (rateLimitStore.size > 1000) {
    for (const [k, v] of rateLimitStore.entries()) {
      if (now > v.resetAt) rateLimitStore.delete(k);
    }
  }
  
  return {
    allowed: entry.count <= maxRequests,
    remaining: Math.max(0, maxRequests - entry.count),
    resetAt: entry.resetAt,
  };
}

/**
 * Verify admin API key from Authorization header or query param
 */
function verifyAdminAuth(req) {
  const adminKey = process.env.ADMIN_API_KEY;
  if (!adminKey) {
    console.warn('[AUTH] ADMIN_API_KEY not set in environment');
    return false;
  }
  
  // Check Authorization header: "Bearer <key>"
  const authHeader = req.headers['authorization'] || '';
  if (authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7) === adminKey;
  }
  
  // Check x-api-key header
  if (req.headers['x-api-key'] === adminKey) return true;
  
  // Check query param (less secure, for bot use)
  if (req.query?.admin_key === adminKey) return true;
  
  return false;
}

/**
 * Set CORS headers
 */
function setCORSHeaders(res) {
  res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key');
}

/**
 * Log request details
 */
function logRequest(req, statusCode, extra = {}) {
  const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 'unknown';
  const log = {
    timestamp: new Date().toISOString(),
    method: req.method,
    path: req.url,
    ip,
    status: statusCode,
    ua: req.headers['user-agent']?.slice(0, 80) || 'unknown',
    ...extra,
  };
  console.log('[REQ]', JSON.stringify(log));
}

/**
 * Send JSON response with standard format
 */
function sendJSON(res, statusCode, data) {
  res.setHeader('Content-Type', 'application/json');
  res.status(statusCode).json(data);
}

/**
 * Main middleware wrapper
 */
function withMiddleware(handler, options = {}) {
  const {
    requireAdmin = false,
    maxRequests = 30,
    windowMs = 60 * 1000,
    allowedMethods = ['GET', 'POST'],
  } = options;

  return async (req, res) => {
    setCORSHeaders(res);
    
    // Handle preflight
    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }
    
    // Method check
    if (!allowedMethods.includes(req.method)) {
      logRequest(req, 405);
      return sendJSON(res, 405, { error: 'Method not allowed' });
    }
    
    // Rate limiting
    const rl = rateLimit(req, maxRequests, windowMs);
    res.setHeader('X-RateLimit-Remaining', rl.remaining);
    
    if (!rl.allowed) {
      logRequest(req, 429, { reason: 'rate_limited' });
      return sendJSON(res, 429, { error: 'Too many requests. Please slow down.' });
    }
    
    // Admin auth
    if (requireAdmin && !verifyAdminAuth(req)) {
      logRequest(req, 401, { reason: 'unauthorized' });
      return sendJSON(res, 401, { error: 'Unauthorized. Valid admin API key required.' });
    }
    
    try {
      await handler(req, res);
      logRequest(req, res.statusCode || 200);
    } catch (err) {
      console.error('[HANDLER ERROR]', err);
      logRequest(req, 500, { error: err.message });
      sendJSON(res, 500, { error: 'Internal server error' });
    }
  };
}

module.exports = {
  withMiddleware,
  verifyAdminAuth,
  logRequest,
  sendJSON,
  setCORSHeaders,
};
