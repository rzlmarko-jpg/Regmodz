"""
Example Client Script - How to use the Key Auth API
in your Python application.

This is what end-users run to verify their license.
"""

import hashlib
import platform
import subprocess
import requests
import sys

# ─── Config (set your API URL here) ──────────────────────────────────────────

API_URL = "https://your-project.vercel.app"  # Replace with your Vercel URL


def get_hwid() -> str:
    """
    Generate a unique Hardware ID for this machine.
    Combines machine UUID + processor info for uniqueness.
    """
    try:
        if platform.system() == "Windows":
            raw = subprocess.check_output(
                "wmic csproduct get UUID", shell=True
            ).decode().strip().split("\n")[-1].strip()
        elif platform.system() == "Linux":
            with open("/etc/machine-id") as f:
                raw = f.read().strip()
        elif platform.system() == "Darwin":
            raw = subprocess.check_output(
                "ioreg -rd1 -c IOPlatformExpertDevice | awk '/IOPlatformUUID/ {print $3}'",
                shell=True,
            ).decode().strip().strip('"')
        else:
            raw = platform.node()
    except Exception:
        raw = platform.node() + platform.processor()

    # Hash for privacy (don't send raw UUID)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def verify_license(key: str) -> dict:
    """
    Verify a license key against the auth server.
    Returns dict with 'status' key.
    """
    hwid = get_hwid()

    try:
        resp = requests.post(
            f"{API_URL}/api/verifyKey",
            json={"key": key.strip().upper(), "hwid": hwid},
            timeout=10,
        )
        return resp.json()
    except requests.exceptions.ConnectionError:
        return {"status": "error", "error": "Cannot connect to license server"}
    except requests.exceptions.Timeout:
        return {"status": "error", "error": "License server timed out"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


def main():
    print("=" * 50)
    print("   MY AWESOME APPLICATION v1.0")
    print("   License Verification Required")
    print("=" * 50)

    if len(sys.argv) > 1:
        key = sys.argv[1]
    else:
        key = input("\nEnter your license key: ").strip()

    if not key:
        print("[ERROR] No key provided.")
        sys.exit(1)

    print(f"\n[*] Verifying key: {key}")
    print("[*] Generating HWID...")

    result = verify_license(key)
    status = result.get("status")

    if status == "valid":
        print(f"\n[✓] License VALID!")
        print(f"    Expires: {result.get('expired_at_human', 'N/A')}")
        print(f"    HWID: {result.get('hwid', 'N/A')[:12]}...")
        print("\n[*] Starting application...\n")
        # Your app logic here

    elif status == "expired":
        print(f"\n[✗] License EXPIRED on {result.get('expired_at_human', 'N/A')}")
        print("    Please purchase a new key.")
        sys.exit(1)

    elif status == "banned":
        print("\n[✗] This license key has been BANNED.")
        print("    Contact support if you believe this is an error.")
        sys.exit(1)

    elif status == "hwid_blocked":
        print(f"\n[✗] License locked to another device.")
        print(f"    Max devices: {result.get('max_devices', 1)}")
        print("    Contact admin to reset HWID.")
        sys.exit(1)

    elif status == "invalid":
        print(f"\n[✗] Invalid license key.")
        sys.exit(1)

    else:
        print(f"\n[✗] Verification failed: {result.get('error', 'Unknown error')}")
        sys.exit(1)


if __name__ == "__main__":
    main()
