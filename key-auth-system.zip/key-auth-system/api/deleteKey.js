/**
 * POST /api/deleteKey
 * Permanently delete a key from database
 * Auth: Admin API key required
 * 
 * Body: { key: string }
 */

const { withMiddleware, sendJSON } = require('../middleware');
const { validateKeyFormat } = require('../utils/keygen');
const { findKey, deleteKey } = require('../utils/database');

async function handler(req, res) {
  const { key } = req.body || {};

  if (!key) {
    return sendJSON(res, 400, { error: 'key is required' });
  }

  const cleanKey = key.trim().toUpperCase();
  if (!validateKeyFormat(cleanKey)) {
    return sendJSON(res, 400, { error: 'Invalid key format' });
  }

  const keyRecord = findKey(cleanKey);
  if (!keyRecord) {
    return sendJSON(res, 404, { error: 'Key not found' });
  }

  const deleted = deleteKey(cleanKey);
  if (!deleted) {
    return sendJSON(res, 500, { error: 'Failed to delete key' });
  }

  return sendJSON(res, 200, {
    status: 'deleted',
    key: cleanKey,
    message: `Key ${cleanKey} has been permanently deleted`,
  });
}

module.exports = withMiddleware(handler, {
  requireAdmin: true,
  allowedMethods: ['POST'],
  maxRequests: 20,
});
