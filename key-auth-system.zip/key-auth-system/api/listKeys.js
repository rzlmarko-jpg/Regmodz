/**
 * GET /api/listKeys
 * List all keys with optional status filter
 * Auth: Admin API key required
 * 
 * Query params:
 *   status: active | expired | banned | all (default: all)
 *   page: number (default: 1)
 *   limit: number (default: 50, max: 200)
 */

const { withMiddleware, sendJSON } = require('../middleware');
const { formatDate, isExpired } = require('../utils/keygen');
const { autoExpireKeys } = require('../utils/database');

async function handler(req, res) {
  // Run auto-expire before listing
  const allKeys = autoExpireKeys();

  const {
    status = 'all',
    page = 1,
    limit = 50,
  } = req.query || {};

  const validStatuses = ['all', 'active', 'expired', 'banned'];
  const filterStatus = validStatuses.includes(status) ? status : 'all';
  const pageNum = Math.max(1, parseInt(page) || 1);
  const limitNum = Math.min(200, Math.max(1, parseInt(limit) || 50));

  // Filter
  let filtered = filterStatus === 'all'
    ? allKeys
    : allKeys.filter(k => k.status === filterStatus);

  // Sort by created_at descending (newest first)
  filtered.sort((a, b) => (b.created_at || 0) - (a.created_at || 0));

  // Paginate
  const total = filtered.length;
  const offset = (pageNum - 1) * limitNum;
  const paginated = filtered.slice(offset, offset + limitNum);

  // Format output (hide full hwid_list by default for security)
  const formatted = paginated.map(k => ({
    key: k.key,
    status: k.status,
    created_at: k.created_at,
    created_at_human: formatDate(k.created_at),
    expired_at: k.expired_at,
    expired_at_human: formatDate(k.expired_at),
    hwid_bound: (k.hwid_list || []).length > 0,
    devices_used: (k.hwid_list || []).length,
    max_devices: k.max_devices || 1,
    usage_count: k.usage_count || 0,
    note: k.note || '',
  }));

  // Summary stats
  const stats = {
    total: allKeys.length,
    active: allKeys.filter(k => k.status === 'active').length,
    expired: allKeys.filter(k => k.status === 'expired').length,
    banned: allKeys.filter(k => k.status === 'banned').length,
  };

  return sendJSON(res, 200, {
    keys: formatted,
    pagination: {
      page: pageNum,
      limit: limitNum,
      total,
      total_pages: Math.ceil(total / limitNum),
    },
    stats,
    filter: filterStatus,
  });
}

module.exports = withMiddleware(handler, {
  requireAdmin: true,
  allowedMethods: ['GET'],
  maxRequests: 30,
});
