/**
 * POST /api/verifyKey
 * Verify a license key with HWID binding (anti-sharing)
 * 
 * Body: { key: string, hwid: string }
 * Public endpoint (no admin auth required)
 */

const { withMiddleware, sendJSON } = require('../middleware');
const { validateKeyFormat, sanitizeHWID, formatDate, isExpired } = require('../utils/keygen');
const { findKey, updateKey, autoExpireKeys } = require('../utils/database');

async function handler(req, res) {
  const { key, hwid } = req.body || {};

  // Input validation
  if (!key || typeof key !== 'string') {
    return sendJSON(res, 400, { status: 'error', error: 'Key is required' });
  }

  const cleanKey = key.trim().toUpperCase();
  if (!validateKeyFormat(cleanKey)) {
    return sendJSON(res, 400, {
      status: 'invalid',
      error: 'Invalid key format. Expected: XXXX-XXXX-XXXX-XXXX',
    });
  }

  const cleanHWID = sanitizeHWID(hwid);
  if (!cleanHWID) {
    return sendJSON(res, 400, { status: 'error', error: 'Valid HWID is required' });
  }

  // Run auto-expire check
  autoExpireKeys();

  // Find key in database
  const keyRecord = findKey(cleanKey);
  if (!keyRecord) {
    return sendJSON(res, 404, { status: 'invalid', error: 'Key not found' });
  }

  // Check banned
  if (keyRecord.status === 'banned') {
    return sendJSON(res, 403, {
      status: 'banned',
      error: 'This key has been banned',
    });
  }

  // Check expired
  if (keyRecord.status === 'expired' || isExpired(keyRecord.expired_at)) {
    // Update status if not already marked
    if (keyRecord.status !== 'expired') {
      updateKey(cleanKey, { status: 'expired' });
    }
    return sendJSON(res, 403, {
      status: 'expired',
      error: 'Key has expired',
      expired_at: keyRecord.expired_at,
      expired_at_human: formatDate(keyRecord.expired_at),
    });
  }

  // HWID logic
  const hwidList = keyRecord.hwid_list || [];
  const isNewHWID = !hwidList.includes(cleanHWID);

  if (isNewHWID) {
    // Check if max devices reached
    if (hwidList.length >= (keyRecord.max_devices || 1)) {
      return sendJSON(res, 403, {
        status: 'hwid_blocked',
        error: 'Maximum device limit reached. Key sharing is not allowed.',
        max_devices: keyRecord.max_devices,
      });
    }

    // Register new HWID
    const updatedList = [...hwidList, cleanHWID];
    const updates = {
      hwid: updatedList[0], // Primary HWID (first registered)
      hwid_list: updatedList,
      usage_count: (keyRecord.usage_count || 0) + 1,
    };
    updateKey(cleanKey, updates);

    return sendJSON(res, 200, {
      status: 'valid',
      message: 'HWID registered successfully',
      expired_at: keyRecord.expired_at,
      expired_at_human: formatDate(keyRecord.expired_at),
      hwid: cleanHWID,
      hwid_registered: true,
      devices_used: updatedList.length,
      max_devices: keyRecord.max_devices,
    });
  }

  // HWID already registered for this key - allow
  updateKey(cleanKey, { usage_count: (keyRecord.usage_count || 0) + 1 });

  return sendJSON(res, 200, {
    status: 'valid',
    expired_at: keyRecord.expired_at,
    expired_at_human: formatDate(keyRecord.expired_at),
    hwid: cleanHWID,
    hwid_registered: false,
    devices_used: hwidList.length,
    max_devices: keyRecord.max_devices,
    usage_count: keyRecord.usage_count + 1,
  });
}

module.exports = withMiddleware(handler, {
  requireAdmin: false,
  allowedMethods: ['POST'],
  maxRequests: 60, // Public endpoint - slightly higher limit
  windowMs: 60 * 1000,
});
