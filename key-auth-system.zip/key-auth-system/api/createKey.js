/**
 * POST /api/createKey
 * Create a new license key
 * 
 * Body: { duration: "1d" | "7d" | "30d", max_devices?: number, note?: string }
 * Auth: Admin API key required
 */

const { withMiddleware, sendJSON } = require('../middleware');
const { generateKey, calcExpiry, formatDate } = require('../utils/keygen');
const { saveKey, findKey, getAllKeys } = require('../utils/database');

async function handler(req, res) {
  const { duration = '7d', max_devices = 1, note = '' } = req.body || {};

  // Validate duration
  const expiredAt = calcExpiry(duration);
  if (!expiredAt) {
    return sendJSON(res, 400, {
      error: 'Invalid duration. Use format: 1h, 1d, 7d, 30d, 1m',
      valid_formats: ['1h', '1d', '7d', '30d', '1m'],
    });
  }

  // Validate max_devices
  const maxDevices = parseInt(max_devices) || 1;
  if (maxDevices < 1 || maxDevices > 10) {
    return sendJSON(res, 400, { error: 'max_devices must be between 1 and 10' });
  }

  // Generate unique key (retry if collision)
  let key;
  let attempts = 0;
  do {
    key = generateKey();
    attempts++;
    if (attempts > 10) {
      return sendJSON(res, 500, { error: 'Failed to generate unique key' });
    }
  } while (findKey(key));

  const now = Date.now();
  const keyData = {
    key,
    status: 'active',
    created_at: now,
    expired_at: expiredAt,
    updated_at: now,
    hwid: null,
    hwid_list: [],
    max_devices: maxDevices,
    usage_count: 0,
    note: note.slice(0, 200),
  };

  const saved = saveKey(keyData);
  if (!saved) {
    return sendJSON(res, 500, { error: 'Failed to save key to database' });
  }

  return sendJSON(res, 201, {
    status: 'created',
    key,
    expired_at: expiredAt,
    expired_at_human: formatDate(expiredAt),
    max_devices: maxDevices,
    duration,
    created_at: now,
  });
}

module.exports = withMiddleware(handler, {
  requireAdmin: true,
  allowedMethods: ['POST'],
  maxRequests: 20,
});
