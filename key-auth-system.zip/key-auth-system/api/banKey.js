/**
 * POST /api/banKey
 * Ban a key (blocks all future verification attempts)
 * Auth: Admin API key required
 * 
 * Body: { key: string, reason?: string }
 */

const { withMiddleware, sendJSON } = require('../middleware');
const { validateKeyFormat, formatDate } = require('../utils/keygen');
const { findKey, updateKey } = require('../utils/database');

async function handler(req, res) {
  const { key, reason = 'Banned by admin' } = req.body || {};

  if (!key) {
    return sendJSON(res, 400, { error: 'key is required' });
  }

  const cleanKey = key.trim().toUpperCase();
  if (!validateKeyFormat(cleanKey)) {
    return sendJSON(res, 400, { error: 'Invalid key format' });
  }

  const keyRecord = findKey(cleanKey);
  if (!keyRecord) {
    return sendJSON(res, 404, { error: 'Key not found' });
  }

  if (keyRecord.status === 'banned') {
    return sendJSON(res, 409, {
      error: 'Key is already banned',
      key: cleanKey,
    });
  }

  const updated = updateKey(cleanKey, {
    status: 'banned',
    ban_reason: reason.slice(0, 200),
    banned_at: Date.now(),
  });

  if (!updated) {
    return sendJSON(res, 500, { error: 'Failed to ban key' });
  }

  return sendJSON(res, 200, {
    status: 'banned',
    key: cleanKey,
    reason,
    banned_at: Date.now(),
    banned_at_human: formatDate(Date.now()),
    message: `Key ${cleanKey} has been banned`,
  });
}

module.exports = withMiddleware(handler, {
  requireAdmin: true,
  allowedMethods: ['POST'],
  maxRequests: 20,
});
