/**
 * POST /api/resetHWID
 * Reset HWID binding for a key (allows re-registration on new device)
 * Auth: Admin API key required
 * 
 * Body: { key: string }
 */

const { withMiddleware, sendJSON } = require('../middleware');
const { validateKeyFormat } = require('../utils/keygen');
const { findKey, updateKey } = require('../utils/database');

async function handler(req, res) {
  const { key } = req.body || {};

  if (!key) {
    return sendJSON(res, 400, { error: 'key is required' });
  }

  const cleanKey = key.trim().toUpperCase();
  if (!validateKeyFormat(cleanKey)) {
    return sendJSON(res, 400, { error: 'Invalid key format' });
  }

  const keyRecord = findKey(cleanKey);
  if (!keyRecord) {
    return sendJSON(res, 404, { error: 'Key not found' });
  }

  if (keyRecord.status === 'banned') {
    return sendJSON(res, 403, { error: 'Cannot reset HWID for banned key' });
  }

  const updated = updateKey(cleanKey, {
    hwid: null,
    hwid_list: [],
  });

  if (!updated) {
    return sendJSON(res, 500, { error: 'Failed to reset HWID' });
  }

  return sendJSON(res, 200, {
    status: 'reset',
    key: cleanKey,
    message: 'HWID binding cleared. Key can now be registered on a new device.',
  });
}

module.exports = withMiddleware(handler, {
  requireAdmin: true,
  allowedMethods: ['POST'],
  maxRequests: 20,
});
