/**
 * GET /api/health
 * Health check endpoint
 */

const { withMiddleware, sendJSON } = require('../middleware');
const { getAllKeys } = require('../utils/database');

async function handler(req, res) {
  const keys = getAllKeys();
  const now = Date.now();

  return sendJSON(res, 200, {
    status: 'ok',
    timestamp: now,
    version: '1.0.0',
    stats: {
      total_keys: keys.length,
      active: keys.filter(k => k.status === 'active').length,
    },
  });
}

module.exports = withMiddleware(handler, {
  requireAdmin: false,
  allowedMethods: ['GET'],
  maxRequests: 60,
});
