/**
 * GET /api/keyInfo?key=XXXX-XXXX-XXXX-XXXX
 * Get detailed information about a specific key
 * Auth: Admin API key required
 */

const { withMiddleware, sendJSON } = require('../middleware');
const { validateKeyFormat, formatDate, isExpired } = require('../utils/keygen');
const { findKey, updateKey, autoExpireKeys } = require('../utils/database');

async function handler(req, res) {
  const key = req.query?.key || req.body?.key;

  if (!key) {
    return sendJSON(res, 400, { error: 'key parameter is required' });
  }

  const cleanKey = key.trim().toUpperCase();
  if (!validateKeyFormat(cleanKey)) {
    return sendJSON(res, 400, { error: 'Invalid key format' });
  }

  // Run auto-expire
  autoExpireKeys();

  const keyRecord = findKey(cleanKey);
  if (!keyRecord) {
    return sendJSON(res, 404, { error: 'Key not found' });
  }

  // Auto-update expired status
  if (keyRecord.status === 'active' && isExpired(keyRecord.expired_at)) {
    updateKey(cleanKey, { status: 'expired' });
    keyRecord.status = 'expired';
  }

  const now = Date.now();
  const timeRemaining = keyRecord.expired_at ? Math.max(0, keyRecord.expired_at - now) : null;
  const daysRemaining = timeRemaining ? Math.floor(timeRemaining / (24 * 60 * 60 * 1000)) : null;

  return sendJSON(res, 200, {
    key: keyRecord.key,
    status: keyRecord.status,
    created_at: keyRecord.created_at,
    created_at_human: formatDate(keyRecord.created_at),
    expired_at: keyRecord.expired_at,
    expired_at_human: formatDate(keyRecord.expired_at),
    days_remaining: daysRemaining,
    hwid: keyRecord.hwid,
    hwid_list: keyRecord.hwid_list || [],
    max_devices: keyRecord.max_devices || 1,
    devices_used: (keyRecord.hwid_list || []).length,
    usage_count: keyRecord.usage_count || 0,
    note: keyRecord.note || '',
    updated_at: keyRecord.updated_at,
  });
}

module.exports = withMiddleware(handler, {
  requireAdmin: true,
  allowedMethods: ['GET', 'POST'],
});
