# 🔐 Key Authentication Server

A production-ready license key management system with:
- ✅ HWID Lock & Anti-Sharing
- ⏳ Expiry-based licenses
- 🤖 Telegram Admin Bot
- ⚡ Vercel Serverless API
- 🛡️ Rate Limiting & Auth

---

## 📁 Project Structure

```
key-auth-system/
├── api/
│   ├── createKey.js     # POST - Generate new license key
│   ├── verifyKey.js     # POST - Verify key + HWID binding
│   ├── keyInfo.js       # GET  - Key details
│   ├── listKeys.js      # GET  - List all keys
│   ├── deleteKey.js     # POST - Delete key
│   ├── banKey.js        # POST - Ban key
│   ├── resetHWID.js     # POST - Reset HWID binding
│   └── health.js        # GET  - Health check
├── bot/
│   └── bot.py           # Telegram admin bot
├── database/
│   └── keys.json        # Seed database
├── middleware/
│   └── index.js         # Auth, rate limit, CORS, logging
├── utils/
│   ├── database.js      # Database read/write helpers
│   └── keygen.js        # Key generation & validation
├── examples/
│   └── client_example.py # How to integrate in client app
├── vercel.json          # Vercel configuration
├── package.json
├── requirements.txt     # Python dependencies
└── .env.example         # Environment variable template
```

---

## 🚀 Deployment Guide

### Step 1: Clone and Set Up Repository

```bash
git clone https://github.com/yourusername/key-auth-system
cd key-auth-system
```

### Step 2: Generate Admin API Key

```bash
# Linux/Mac
openssl rand -hex 32

# Windows PowerShell
[System.Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
```

Save this key — you'll need it for Vercel and the bot config.

### Step 3: Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# For production
vercel --prod
```

During deployment, set these environment variables in Vercel Dashboard
(Settings → Environment Variables):

| Variable | Value |
|---|---|
| `ADMIN_API_KEY` | Your generated secret key |
| `DB_PATH` | `/tmp/keys.json` |
| `ALLOWED_ORIGIN` | `*` (or your domain) |

> ⚠️ **Important**: Vercel's `/tmp` resets between deployments. For persistent
> storage, see the [Vercel KV section](#persistent-storage-with-vercel-kv).

### Step 4: Set Up Telegram Bot

1. Open [@BotFather](https://t.me/BotFather) on Telegram
2. Send `/newbot` and follow instructions
3. Save the token you receive

Get your Telegram user ID:
1. Open [@userinfobot](https://t.me/userinfobot)
2. Send `/start`
3. Note your numeric user ID

### Step 5: Configure and Run Bot

```bash
# Install Python dependencies
pip install -r requirements.txt

# Create .env file from example
cp .env.example .env
```

Edit `.env`:
```env
TELEGRAM_BOT_TOKEN=your_token_from_botfather
TELEGRAM_ADMIN_IDS=your_numeric_user_id
API_BASE_URL=https://your-project.vercel.app
ADMIN_API_KEY=your_secret_admin_key
```

Run the bot:
```bash
# Direct
python bot/bot.py

# Or with environment file
export $(cat .env | xargs) && python bot/bot.py

# Background (Linux)
nohup python bot/bot.py &

# As a service (recommended for production)
# See systemd section below
```

---

## 📡 API Reference

### Authentication

Admin endpoints require one of:
- Header: `Authorization: Bearer YOUR_ADMIN_KEY`
- Header: `x-api-key: YOUR_ADMIN_KEY`
- Query: `?admin_key=YOUR_ADMIN_KEY`

---

### POST /api/createKey

Create a new license key.

**Request:**
```json
{
  "duration": "7d",
  "max_devices": 1,
  "note": "Customer order #123"
}
```

**Response:**
```json
{
  "status": "created",
  "key": "ABCD-1234-EFGH-5678",
  "expired_at": 1720000000000,
  "expired_at_human": "2024-07-03 12:00:00 UTC",
  "max_devices": 1,
  "duration": "7d",
  "created_at": 1719395200000
}
```

**Duration formats:** `1h`, `1d`, `7d`, `30d`, `1m`

---

### POST /api/verifyKey

Verify a key with HWID binding (use in your client app).

**Request:**
```json
{
  "key": "ABCD-1234-EFGH-5678",
  "hwid": "a3f8b2c1d4e5..."
}
```

**Response - Valid:**
```json
{
  "status": "valid",
  "expired_at": 1720000000000,
  "expired_at_human": "2024-07-03 12:00:00 UTC",
  "hwid": "a3f8b2c1d4e5...",
  "hwid_registered": false,
  "devices_used": 1,
  "max_devices": 1,
  "usage_count": 5
}
```

**Response - Possible statuses:**
| Status | HTTP | Meaning |
|---|---|---|
| `valid` | 200 | Key is valid |
| `invalid` | 404 | Key not found |
| `expired` | 403 | Key has expired |
| `banned` | 403 | Key is banned |
| `hwid_blocked` | 403 | Max devices reached (sharing detected) |

---

### GET /api/keyInfo?key=XXXX-XXXX-XXXX-XXXX

Get detailed key information. **Admin only.**

---

### GET /api/listKeys?status=active&page=1&limit=50

List keys with optional filtering. **Admin only.**

**Query params:**
- `status`: `all` | `active` | `expired` | `banned`
- `page`: page number (default: 1)
- `limit`: results per page (default: 50, max: 200)

---

### POST /api/deleteKey

**Admin only.** Body: `{ "key": "XXXX-XXXX-XXXX-XXXX" }`

---

### POST /api/banKey

**Admin only.** Body: `{ "key": "...", "reason": "Optional reason" }`

---

### POST /api/resetHWID

Reset HWID binding (allow re-registration). **Admin only.**
Body: `{ "key": "XXXX-XXXX-XXXX-XXXX" }`

---

## 🤖 Bot Commands

| Command | Description | Example |
|---|---|---|
| `/start` | Show admin menu | `/start` |
| `/gen <dur>` | Generate key | `/gen 7d` |
| `/check <key>` | View key details | `/check ABCD-1234-EFGH-5678` |
| `/list [status]` | List keys | `/list active` |
| `/del <key>` | Delete key | `/del ABCD-1234-EFGH-5678` |
| `/ban <key> [reason]` | Ban key | `/ban ABCD-1234-EFGH-5678 sharing` |
| `/reset <key>` | Reset HWID | `/reset ABCD-1234-EFGH-5678` |
| `/help` | Show help | `/help` |

---

## 🔑 Client Integration

```python
import hashlib, platform, requests

API_URL = "https://your-project.vercel.app"

def get_hwid():
    import subprocess
    try:
        raw = subprocess.check_output("wmic csproduct get UUID", shell=True).decode()
        raw = raw.strip().split("\n")[-1].strip()
    except:
        raw = platform.node()
    return hashlib.sha256(raw.encode()).hexdigest()[:32]

def check_license(key):
    r = requests.post(f"{API_URL}/api/verifyKey", 
                      json={"key": key, "hwid": get_hwid()}, timeout=10)
    return r.json()

result = check_license("ABCD-1234-EFGH-5678")
if result["status"] != "valid":
    print("Invalid license:", result.get("error"))
    exit(1)

print("License OK, starting app...")
```

---

## 💾 Persistent Storage with Vercel KV

For persistent storage across deployments, upgrade to Vercel KV:

1. Enable KV in Vercel Dashboard → Storage → Create KV Store
2. Install: `npm install @vercel/kv`
3. Replace `utils/database.js` with KV implementation:

```javascript
const { kv } = require('@vercel/kv');

async function findKey(keyValue) {
  return await kv.get(`key:${keyValue}`);
}

async function saveKey(keyData) {
  await kv.set(`key:${keyData.key}`, keyData);
  await kv.sadd('all_keys', keyData.key);
  return true;
}
```

---

## 🔧 Run as systemd Service (Linux)

```ini
# /etc/systemd/system/keyauth-bot.service
[Unit]
Description=Key Auth Telegram Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/key-auth-system
EnvironmentFile=/home/ubuntu/key-auth-system/.env
ExecStart=/usr/bin/python3 bot/bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable keyauth-bot
sudo systemctl start keyauth-bot
sudo systemctl status keyauth-bot
```

---

## ⚠️ Security Notes

1. **Never expose `ADMIN_API_KEY`** in client code or public repos
2. Add your repo to `.gitignore` for `.env` files
3. Use HTTPS only (Vercel provides this automatically)
4. Restrict `ALLOWED_ORIGIN` to your domain in production
5. The HWID is hashed in `client_example.py` — never send raw machine IDs
