/**
 * Key Generator Utility
 * Generates secure license keys in XXXX-XXXX-XXXX-XXXX format
 */

const crypto = require('crypto');

/**
 * Generate cryptographically secure random key
 * Format: XXXX-XXXX-XXXX-XXXX (uppercase alphanumeric)
 */
function generateKey() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const segments = 4;
  const segmentLength = 4;
  const parts = [];

  for (let i = 0; i < segments; i++) {
    let segment = '';
    const bytes = crypto.randomBytes(segmentLength);
    for (let j = 0; j < segmentLength; j++) {
      segment += chars[bytes[j] % chars.length];
    }
    parts.push(segment);
  }

  return parts.join('-');
}

/**
 * Parse duration string to milliseconds
 * Supports: 1d, 7d, 30d, 1h, 1w, 1m
 */
function parseDuration(duration) {
  const units = {
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
    m: 30 * 24 * 60 * 60 * 1000,
  };

  const match = duration.toString().toLowerCase().match(/^(\d+)([hdwm])$/);
  if (!match) return null;

  const value = parseInt(match[1]);
  const unit = match[2];

  if (!units[unit] || value <= 0 || value > 365) return null;
  return value * units[unit];
}

/**
 * Calculate expiry timestamp from duration string
 */
function calcExpiry(duration) {
  const ms = parseDuration(duration);
  if (!ms) return null;
  return Date.now() + ms;
}

/**
 * Format timestamp to human-readable date
 */
function formatDate(timestamp) {
  if (!timestamp) return 'Never';
  return new Date(timestamp).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
}

/**
 * Check if key is expired
 */
function isExpired(expiredAt) {
  if (!expiredAt) return false;
  return Date.now() > expiredAt;
}

/**
 * Validate key format
 */
function validateKeyFormat(key) {
  return /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(key);
}

/**
 * Sanitize HWID (remove special chars, max 128 chars)
 */
function sanitizeHWID(hwid) {
  if (!hwid || typeof hwid !== 'string') return null;
  return hwid.replace(/[^a-zA-Z0-9_\-:.]/g, '').slice(0, 128);
}

module.exports = {
  generateKey,
  parseDuration,
  calcExpiry,
  formatDate,
  isExpired,
  validateKeyFormat,
  sanitizeHWID,
};
