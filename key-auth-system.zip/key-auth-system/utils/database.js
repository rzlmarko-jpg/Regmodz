/**
 * Database Utility - File-based JSON storage
 * Compatible with Vercel Serverless (using /tmp for writes)
 * For production: swap with Vercel KV or PlanetScale
 */

const fs = require('fs');
const path = require('path');

// In Vercel, use /tmp for writable storage
// For persistent storage, use Vercel KV (see README)
const DB_PATH = process.env.DB_PATH || path.join('/tmp', 'keys.json');
const SEED_PATH = path.join(process.cwd(), 'database', 'keys.json');

/**
 * Initialize database - copy seed file to /tmp if not exists
 */
function initDB() {
  if (!fs.existsSync(DB_PATH)) {
    // Load seed data from repo if available
    if (fs.existsSync(SEED_PATH)) {
      const seed = fs.readFileSync(SEED_PATH, 'utf8');
      fs.writeFileSync(DB_PATH, seed);
    } else {
      fs.writeFileSync(DB_PATH, JSON.stringify({ keys: [], meta: { created_at: Date.now(), version: '1.0.0' } }, null, 2));
    }
  }
}

/**
 * Read all data from database
 */
function readDB() {
  try {
    initDB();
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('[DB] Read error:', err.message);
    return { keys: [], meta: { created_at: Date.now(), version: '1.0.0' } };
  }
}

/**
 * Write data to database
 */
function writeDB(data) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
    return true;
  } catch (err) {
    console.error('[DB] Write error:', err.message);
    return false;
  }
}

/**
 * Get all keys
 */
function getAllKeys() {
  const db = readDB();
  return db.keys || [];
}

/**
 * Find key by value
 */
function findKey(keyValue) {
  const keys = getAllKeys();
  return keys.find(k => k.key === keyValue) || null;
}

/**
 * Save new key
 */
function saveKey(keyData) {
  const db = readDB();
  db.keys = db.keys || [];
  db.keys.push(keyData);
  return writeDB(db);
}

/**
 * Update existing key
 */
function updateKey(keyValue, updates) {
  const db = readDB();
  const idx = db.keys.findIndex(k => k.key === keyValue);
  if (idx === -1) return false;
  db.keys[idx] = { ...db.keys[idx], ...updates, updated_at: Date.now() };
  return writeDB(db);
}

/**
 * Delete key
 */
function deleteKey(keyValue) {
  const db = readDB();
  const before = db.keys.length;
  db.keys = db.keys.filter(k => k.key !== keyValue);
  if (db.keys.length === before) return false;
  return writeDB(db);
}

/**
 * Auto-expire: update all expired keys
 */
function autoExpireKeys() {
  const db = readDB();
  const now = Date.now();
  let changed = false;

  db.keys = db.keys.map(k => {
    if (k.status === 'active' && k.expired_at && now > k.expired_at) {
      changed = true;
      return { ...k, status: 'expired', updated_at: now };
    }
    return k;
  });

  if (changed) writeDB(db);
  return db.keys;
}

module.exports = {
  readDB,
  writeDB,
  getAllKeys,
  findKey,
  saveKey,
  updateKey,
  deleteKey,
  autoExpireKeys,
};
